﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Common;
using System.Diagnostics.Metrics;
using System.IO;
using System.Net.NetworkInformation;
using System.Reflection.PortableExecutable;
using System.Reflection;

public class CSVParser
{
    private List<string> headers;
    private List<Dictionary<string, string>> rows;

    public CSVParser(string filePath)
    {
        headers = new List<string>();
        rows = new List<Dictionary<string, string>>();
        ParseCSVFile(filePath);
    }

    /*
     * Using StreamReader, the method reads the CSV file one line at a time.
     * The first line is assumed to be the header row, which contains the column names.This is stored in the headers list.
     * For each subsequent line, it uses the ParseLine method to split the line into individual fields. 
     * It then creates a dictionary where the keys are the column names from headers, and the values are the corresponding fields for that row. 
     * Each dictionary is added to the rows list.
     * If a row has fewer fields than there are headers, it fills missing fields with empty strings.
    */
    private void ParseCSVFile(string filePath)
    {
        using (StreamReader reader = new StreamReader(filePath))
        {
            string line;
            bool isHeader = true;

            while ((line = reader.ReadLine()) != null)
            {
                List<string> fields = ParseLine(line);

                if (isHeader)
                {
                    headers = fields;
                    isHeader = false;
                }
                else
                {
                    Dictionary<string, string> row = new Dictionary<string, string>();
                    for (int i = 0; i < headers.Count; i++)
                    {
                        row[headers[i]] = fields.Count > i ? fields[i] : string.Empty;
                    }
                    rows.Add(row);
                }
            }
        }
    }

    /*
     * Core method that processes each line of the CSV file to handle special cases such as commas inside quoted fields and escaped quotes.
     */
    private List<string> ParseLine(string line)
    {
        List<string> fields = new List<string>();
        bool insideQuotes = false;
        string currentField = string.Empty;

        for (int i = 0; i < line.Length; i++)
        {
            char c = line[i];

            if (insideQuotes)
            {
                if (c == '"')
                {
                    // Check if it's an escaped quote
                    if (i + 1 < line.Length && line[i + 1] == '"')
                    {
                        currentField += '"'; 
                    }
                    else
                    {
                        insideQuotes = false; 
                    }
                }
                else
                {
                    currentField += c;
                }
            }
            else
            {
                if (c == '"')
                {
                    insideQuotes = true;
                }
                else if (c == ',')
                {
                    fields.Add(currentField);
                    currentField = string.Empty;
                }
                else
                {
                    currentField += c;
                }
            }
        }

        // Add the last field
        fields.Add(currentField);
        return fields;
    }

    public Dictionary<string, string> GetRow(int index)
    {
        if (index < 0 || index >= rows.Count)
            throw new IndexOutOfRangeException("Row index out of range.");
        return rows[index];
    }

    public string GetField(int rowIndex, string columnName)
    {
        if (!headers.Contains(columnName))
            throw new ArgumentException($"Column '{columnName}' does not exist.");

        var row = GetRow(rowIndex);
        return row[columnName];
    }

    public int GetRowCount()
    {
        return rows.Count;
    }

    public void PrintAll()
    {
        Console.WriteLine(string.Join(", ", headers));

        foreach (var row in rows)
        {
            List<string> rowValues = new List<string>();
            foreach (var header in headers)
            {
                rowValues.Add(row[header]);
            }
            Console.WriteLine(string.Join(", ", rowValues));
        }
    }
}