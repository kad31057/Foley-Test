﻿
class Program
{
    static void Main()
    {
        // Replace with the path to your CSV file
        string csvFilePath = "test.csv";

        CSVParser parser = new CSVParser(csvFilePath);

        // Print all rows
        parser.PrintAll();
    }
}
